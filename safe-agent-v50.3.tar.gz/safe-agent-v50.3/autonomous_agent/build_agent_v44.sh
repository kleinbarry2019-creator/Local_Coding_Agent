#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION=44

OLLAMA_MODEL="${OLLAMA_MODEL:-qwen2.5-coder:7b-instruct}"
OLLAMA_URL="${OLLAMA_URL:-http://127.0.0.1:11434/api/chat}"

export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
cd "$ROOT"

echo "=========================================="
echo " SAFE AGENT V44 - MISSION POLICY"
echo "=========================================="
echo "Project: $ROOT"
echo "Model:   $OLLAMA_MODEL"
echo

mkdir -p runtime tests tools backups logs

# ---------------------------------------------------------
# Frische V44-Auditkette
# ---------------------------------------------------------

if [[ -f audit_log.jsonl ]]; then
    if [[ -s audit_log.jsonl ]]; then
        backup="logs/audit_pre_v44_$(date +%Y%m%d_%H%M%S).jsonl"
        cp -f audit_log.jsonl "$backup"
        echo "Altes Audit archiviert: $backup"
    fi
    rm -f audit_log.jsonl
fi

rm -f audit_head.sha256

cat > safe_agent_v44.py <<'PY'
#!/usr/bin/env python3

import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request
from pathlib import Path


VERSION = 44

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / "runtime"

STATE_FILE = ROOT / "agent_state.json"
STATE_BACKUP = ROOT / "agent_state.json.bak"
STATE_HASH = ROOT / "agent_state.sha256"

AUDIT_FILE = ROOT / "audit_log.jsonl"
AUDIT_HEAD_FILE = ROOT / "audit_head.sha256"

MAX_STATE_BYTES = 16384
MAX_AUDIT_BYTES = 1048576
MAX_CONTENT_BYTES = 262144
MAX_OUTPUT_CHARS = 8192

MAX_STEPS = 20
MAX_TOOL_CALLS = 20

MAX_READ_CALLS = 50
MAX_WRITE_CALLS = 20
MAX_EXEC_CALLS = 10

MAX_SCRIPT_ARGS = 16

COMMAND_TIMEOUT = 15


OLLAMA_URL = os.environ.get(
    "OLLAMA_URL",
    "http://127.0.0.1:11434/api/chat",
)

MODEL = os.environ.get(
    "OLLAMA_MODEL",
    "qwen2.5-coder:7b-instruct",
)


# =========================================================
# MISSION POLICY
# =========================================================

DEFAULT_POLICY = {
    "list_files": True,
    "read_file": True,
    "write_file": True,
    "run_python": True,
}

READ_ONLY_POLICY = {
    "list_files": True,
    "read_file": True,
    "write_file": False,
    "run_python": False,
}

NO_EXEC_POLICY = {
    "list_files": True,
    "read_file": True,
    "write_file": True,
    "run_python": False,
}


def normalize_policy(policy):
    if not isinstance(policy, dict):
        raise RuntimeError(
            "FAIL-CLOSED: Mission Policy muss Objekt sein."
        )

    allowed = set(DEFAULT_POLICY)

    if set(policy) != allowed:
        raise RuntimeError(
            "FAIL-CLOSED: Ungültige Mission Policy."
        )

    if not all(
        isinstance(value, bool)
        for value in policy.values()
    ):
        raise RuntimeError(
            "FAIL-CLOSED: Policy-Werte müssen bool sein."
        )

    return dict(policy)


def policy_digest(policy):
    return hashlib.sha256(
        json.dumps(
            policy,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()


def build_mission_policy():
    raw = os.environ.get(
        "SAFE_AGENT_POLICY",
        "default",
    )

    if raw == "default":
        return normalize_policy(
            DEFAULT_POLICY
        )

    if raw == "readonly":
        return normalize_policy(
            READ_ONLY_POLICY
        )

    if raw == "noexec":
        return normalize_policy(
            NO_EXEC_POLICY
        )

    raise RuntimeError(
        "FAIL-CLOSED: Unbekannte SAFE_AGENT_POLICY."
    )


# =========================================================
# STATE
# =========================================================

def default_state():
    return {
        "version": VERSION,
        "tasks_completed": 0,
        "last_result": None,
    }


def validate_state(state):
    if not isinstance(state, dict):
        raise RuntimeError(
            "FAIL-CLOSED: State ist kein Objekt."
        )

    required = {
        "version",
        "tasks_completed",
        "last_result",
    }

    missing = required - set(state)

    if missing:
        raise RuntimeError(
            f"FAIL-CLOSED: State-Felder fehlen: {sorted(missing)}"
        )

    if state["version"] != VERSION:
        raise RuntimeError(
            "FAIL-CLOSED: Falsche State-Version."
        )

    if (
        not isinstance(
            state["tasks_completed"],
            int,
        )
        or isinstance(
            state["tasks_completed"],
            bool,
        )
        or state["tasks_completed"] < 0
    ):
        raise RuntimeError(
            "FAIL-CLOSED: tasks_completed ungültig."
        )

    if (
        state["last_result"] is not None
        and not isinstance(
            state["last_result"],
            str,
        )
    ):
        raise RuntimeError(
            "FAIL-CLOSED: last_result ungültig."
        )

    return state


def canonical_json(value):
    return json.dumps(
        value,
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
    )


def state_digest(state):
    return hashlib.sha256(
        canonical_json(state).encode("utf-8")
    ).hexdigest()


def atomic_write(path, data):
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fd, tmp_name = tempfile.mkstemp(
        prefix=f".{path.name}.",
        dir=str(path.parent),
        text=True,
    )

    tmp = Path(tmp_name)

    try:
        with os.fdopen(
            fd,
            "w",
            encoding="utf-8",
        ) as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())

        os.replace(tmp, path)

    finally:
        if tmp.exists():
            tmp.unlink()


def verify_state_hash(state):
    if not STATE_HASH.exists():
        raise RuntimeError(
            "FAIL-CLOSED: State-Hash fehlt."
        )

    actual = STATE_HASH.read_text(
        encoding="utf-8"
    ).strip()

    expected = state_digest(state)

    if actual != expected:
        raise RuntimeError(
            "FAIL-CLOSED: State-Hash stimmt nicht."
        )


def save_state(state):
    validate_state(state)

    encoded = json.dumps(
        state,
        ensure_ascii=False,
        indent=2,
    )

    if len(
        encoded.encode("utf-8")
    ) > MAX_STATE_BYTES:
        raise RuntimeError(
            "FAIL-CLOSED: State zu groß."
        )

    if STATE_FILE.exists():
        shutil.copy2(
            STATE_FILE,
            STATE_BACKUP,
        )

    atomic_write(
        STATE_FILE,
        encoded + "\n",
    )

    atomic_write(
        STATE_HASH,
        state_digest(state) + "\n",
    )


def load_one_state(path):
    if not path.exists():
        return None

    if path.stat().st_size > MAX_STATE_BYTES:
        raise RuntimeError(
            f"FAIL-CLOSED: State zu groß: {path}"
        )

    try:
        state = json.loads(
            path.read_text(
                encoding="utf-8"
            )
        )

        return validate_state(state)

    except Exception:
        return None


def load_state():
    current = load_one_state(
        STATE_FILE
    )

    if current is not None:
        verify_state_hash(current)
        return current

    backup = load_one_state(
        STATE_BACKUP
    )

    if backup is not None:
        save_state(backup)

        audit(
            "STATE_RECOVERY",
            {
                "source": str(STATE_BACKUP),
            },
        )

        return backup

    state = default_state()

    save_state(state)

    audit(
        "STATE_INITIALIZED",
        {},
    )

    return state


# =========================================================
# AUDIT CHAIN
# =========================================================

def audit_digest(entry, previous):
    return hashlib.sha256(
        (
            previous
            + "\n"
            + canonical_json(entry)
        ).encode("utf-8")
    ).hexdigest()


def read_audit_head():
    if not AUDIT_HEAD_FILE.exists():
        return "0" * 64

    value = AUDIT_HEAD_FILE.read_text(
        encoding="utf-8"
    ).strip()

    if len(value) != 64:
        raise RuntimeError(
            "FAIL-CLOSED: Audit-Head ungültig."
        )

    return value


def audit(event, details):
    entry = {
        "timestamp": datetime.datetime.now(
            datetime.timezone.utc
        ).isoformat(),
        "event": event,
        "details": details,
    }

    if (
        AUDIT_FILE.exists()
        and AUDIT_FILE.stat().st_size
        > MAX_AUDIT_BYTES
    ):
        raise RuntimeError(
            "FAIL-CLOSED: Audit-Log zu groß."
        )

    previous = read_audit_head()

    digest = audit_digest(
        entry,
        previous,
    )

    record = {
        "prev": previous,
        "digest": digest,
        "entry": entry,
    }

    with AUDIT_FILE.open(
        "a",
        encoding="utf-8",
    ) as handle:
        handle.write(
            json.dumps(
                record,
                ensure_ascii=False,
                sort_keys=True,
            )
            + "\n"
        )

    atomic_write(
        AUDIT_HEAD_FILE,
        digest + "\n",
    )


def verify_audit_chain():
    if not AUDIT_FILE.exists():
        return True

    previous = "0" * 64

    with AUDIT_FILE.open(
        "r",
        encoding="utf-8",
    ) as handle:
        for line_no, line in enumerate(
            handle,
            1,
        ):
            if not line.strip():
                continue

            record = json.loads(line)

            if set(record) != {
                "prev",
                "digest",
                "entry",
            }:
                raise RuntimeError(
                    f"FAIL-CLOSED: Audit-Schema Zeile {line_no}"
                )

            if record["prev"] != previous:
                raise RuntimeError(
                    f"FAIL-CLOSED: Audit-Kette Zeile {line_no}"
                )

            expected = audit_digest(
                record["entry"],
                previous,
            )

            if record["digest"] != expected:
                raise RuntimeError(
                    f"FAIL-CLOSED: Audit-Hash Zeile {line_no}"
                )

            previous = record["digest"]

    if read_audit_head() != previous:
        raise RuntimeError(
            "FAIL-CLOSED: Audit-Head stimmt nicht."
        )

    return True


# =========================================================
# PATH POLICY
# =========================================================

def resolve_runtime_path(path_text):
    if not isinstance(
        path_text,
        str,
    ):
        raise PermissionError(
            "path muss String sein."
        )

    if not path_text.strip():
        raise PermissionError(
            "Leerer Pfad."
        )

    # Beide Darstellungen werden strikt auf den
    # Runtime-Workspace reduziert.
    if path_text.startswith("/workspace/"):
        path_text = path_text[
            len("/workspace/") :
        ]

    elif path_text == "/workspace":
        path_text = "."

    elif path_text.startswith("/"):
        raise PermissionError(
            "Absoluter Pfad außerhalb von /workspace."
        )

    candidate = (
        RUNTIME / path_text
    ).resolve(
        strict=False
    )

    try:
        candidate.relative_to(
            RUNTIME
        )
    except ValueError as exc:
        raise PermissionError(
            "Pfad außerhalb des Runtime-Workspace."
        ) from exc

    return candidate


# =========================================================
# TOOL IMPLEMENTATIONS
# =========================================================

def list_files():
    RUNTIME.mkdir(
        parents=True,
        exist_ok=True,
    )

    return sorted(
        path.relative_to(
            RUNTIME
        ).as_posix()
        for path in RUNTIME.rglob("*")
        if path.is_file()
    )


def read_file(path):
    target = resolve_runtime_path(
        path
    )

    if not target.exists():
        raise FileNotFoundError(
            f"Datei nicht gefunden: {path}"
        )

    if not target.is_file():
        raise PermissionError(
            "Kein regulärer Dateipfad."
        )

    if target.stat().st_size > MAX_CONTENT_BYTES:
        raise PermissionError(
            "Datei überschreitet Größenlimit."
        )

    return target.read_text(
        encoding="utf-8"
    )


def write_file(path, content):
    if not isinstance(
        content,
        str,
    ):
        raise TypeError(
            "content muss String sein."
        )

    encoded = content.encode(
        "utf-8"
    )

    if len(encoded) > MAX_CONTENT_BYTES:
        raise PermissionError(
            "Inhalt überschreitet Größenlimit."
        )

    target = resolve_runtime_path(
        path
    )

    target.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    atomic_write(
        target,
        content,
    )

    return {
        "path": target.relative_to(
            RUNTIME
        ).as_posix(),
        "bytes": len(encoded),
    }


def run_python(script, args=None):
    if args is None:
        args = []

    if not isinstance(
        args,
        list,
    ):
        raise TypeError(
            "args muss Liste sein."
        )

    if len(args) > MAX_SCRIPT_ARGS:
        raise PermissionError(
            "Zu viele Script-Argumente."
        )

    if not all(
        isinstance(
            item,
            str,
        )
        for item in args
    ):
        raise TypeError(
            "args dürfen nur Strings enthalten."
        )

    script_path = resolve_runtime_path(
        script
    )

    if script_path.suffix != ".py":
        raise PermissionError(
            "Nur .py-Skripte erlaubt."
        )

    if not script_path.is_file():
        raise FileNotFoundError(
            f"Skript nicht gefunden: {script}"
        )

    relative_script = (
        script_path
        .relative_to(RUNTIME)
        .as_posix()
    )

    command = [
        "/usr/bin/bwrap",
        "--die-with-parent",

        "--unshare-user",
        "--unshare-pid",
        "--unshare-ipc",
        "--unshare-net",
        "--unshare-uts",
        "--unshare-cgroup",

        "--cap-drop",
        "ALL",

        "--ro-bind",
        "/usr",
        "/usr",

        "--ro-bind",
        "/bin",
        "/bin",

        "--ro-bind",
        "/lib",
        "/lib",

        "--ro-bind",
        "/lib64",
        "/lib64",

        "--ro-bind",
        str(ROOT),
        "/agent",

        "--bind",
        str(RUNTIME),
        "/workspace",

        "--proc",
        "/proc",

        "--dev",
        "/dev",

        "--tmpfs",
        "/etc",

        "--tmpfs",
        "/tmp",

        "--tmpfs",
        "/var",

        "--chdir",
        "/workspace",

        sys.executable,
        "/workspace/" + relative_script,
        *args,
    ]

    try:
        result = subprocess.run(
            command,
            cwd=ROOT,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=COMMAND_TIMEOUT,
            shell=False,
            check=False,
        )

    except subprocess.TimeoutExpired as exc:
        return {
            "status": "TIMEOUT",
            "exit_code": None,
            "stdout": "",
            "stderr": str(exc),
        }

    return {
        "status": (
            "OK"
            if result.returncode == 0
            else "ERROR"
        ),
        "exit_code": result.returncode,
        "stdout": result.stdout[
            :MAX_OUTPUT_CHARS
        ],
        "stderr": result.stderr[
            :MAX_OUTPUT_CHARS
        ],
    }


TOOL_NAMES = {
    "list_files",
    "read_file",
    "write_file",
    "run_python",
}


# =========================================================
# MISSION TOOL BUDGET
# =========================================================

class MissionBudget:
    def __init__(self):
        self.total = 0
        self.reads = 0
        self.writes = 0
        self.execs = 0

    def check(self, name):
        if self.total >= MAX_TOOL_CALLS:
            raise RuntimeError(
                "FAIL-CLOSED: Tool-Budget erschöpft."
            )

        if name in {
            "list_files",
            "read_file",
        }:
            if self.reads >= MAX_READ_CALLS:
                raise RuntimeError(
                    "FAIL-CLOSED: Read-Budget erschöpft."
                )

        if name == "write_file":
            if self.writes >= MAX_WRITE_CALLS:
                raise RuntimeError(
                    "FAIL-CLOSED: Write-Budget erschöpft."
                )

        if name == "run_python":
            if self.execs >= MAX_EXEC_CALLS:
                raise RuntimeError(
                    "FAIL-CLOSED: Execute-Budget erschöpft."
                )

    def consume(self, name):
        self.total += 1

        if name in {
            "list_files",
            "read_file",
        }:
            self.reads += 1

        elif name == "write_file":
            self.writes += 1

        elif name == "run_python":
            self.execs += 1


def execute_tool(
    name,
    arguments,
    policy,
    budget,
):
    if name not in TOOL_NAMES:
        raise PermissionError(
            f"Tool nicht erlaubt: {name}"
        )

    if not policy.get(
        name,
        False,
    ):
        raise PermissionError(
            f"Tool durch Mission Policy verboten: {name}"
        )

    if not isinstance(
        arguments,
        dict,
    ):
        raise TypeError(
            "arguments muss Objekt sein."
        )

    budget.check(name)

    if name == "list_files":
        if arguments:
            raise PermissionError(
                "list_files akzeptiert keine Argumente."
            )

        result = list_files()

    elif name == "read_file":
        if set(arguments) != {"path"}:
            raise PermissionError(
                "read_file erwartet exakt path."
            )

        result = read_file(
            arguments["path"]
        )

    elif name == "write_file":
        if set(arguments) != {
            "path",
            "content",
        }:
            raise PermissionError(
                "write_file erwartet path und content."
            )

        result = write_file(
            arguments["path"],
            arguments["content"],
        )

    elif name == "run_python":
        if set(arguments) - {
            "script",
            "args",
        }:
            raise PermissionError(
                "run_python enthält unerlaubte Argumente."
            )

        result = run_python(
            arguments["script"],
            arguments.get(
                "args",
                [],
            ),
        )

    else:
        raise RuntimeError(
            "Unbekanntes Tool."
        )

    budget.consume(name)

    return result


# =========================================================
# MODEL
# =========================================================

def ask_model(messages):
    payload = {
        "model": MODEL,
        "messages": messages,
        "stream": False,
        "options": {
            "temperature": 0,
        },
    }

    request = urllib.request.Request(
        OLLAMA_URL,
        data=json.dumps(
            payload
        ).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
        },
    )

    try:
        with urllib.request.urlopen(
            request,
            timeout=60,
        ) as response:
            body = json.load(response)

    except urllib.error.HTTPError as exc:
        detail = exc.read().decode(
            "utf-8",
            errors="replace",
        )

        raise RuntimeError(
            f"Ollama HTTP {exc.code}: {detail}"
        ) from exc

    except Exception as exc:
        raise RuntimeError(
            f"Ollama nicht erreichbar: {exc}"
        ) from exc

    message = body.get("message")

    if not isinstance(
        message,
        dict,
    ):
        raise RuntimeError(
            "Ollama-Antwort enthält keine message."
        )

    content = message.get("content")

    if not isinstance(
        content,
        str,
    ):
        raise RuntimeError(
            "Ollama-Antwort enthält keinen Text."
        )

    return content.strip()


# =========================================================
# PROTOCOL
# =========================================================

def normalize_model_json(text):
    if not isinstance(
        text,
        str,
    ):
        raise RuntimeError(
            "FAIL-CLOSED: Modellantwort muss Text sein."
        )

    value = text.strip()

    if (
        value.startswith("```")
        and value.endswith("```")
    ):
        lines = value.splitlines()

        if len(lines) < 3:
            raise RuntimeError(
                "FAIL-CLOSED: Ungültiger Markdown-Codeblock."
            )

        opening = lines[0].strip().lower()
        closing = lines[-1].strip()

        if closing != "```":
            raise RuntimeError(
                "FAIL-CLOSED: Codeblock nicht korrekt geschlossen."
            )

        if opening not in {
            "```",
            "```json",
        }:
            raise RuntimeError(
                "FAIL-CLOSED: Nur JSON-Codeblock erlaubt."
            )

        value = "\n".join(
            lines[1:-1]
        ).strip()

    if not value:
        raise RuntimeError(
            "FAIL-CLOSED: Leere Modellantwort."
        )

    return value


def parse_action(text):
    value = normalize_model_json(
        text
    )

    try:
        obj = json.loads(
            value
        )

    except json.JSONDecodeError as exc:
        raise RuntimeError(
            "FAIL-CLOSED: Antwort ist kein einzelnes JSON."
        ) from exc

    if not isinstance(
        obj,
        dict,
    ):
        raise RuntimeError(
            "FAIL-CLOSED: JSON-Objekt erwartet."
        )

    if set(obj) == {
        "action",
        "name",
        "arguments",
    }:
        if obj["action"] != "tool":
            raise RuntimeError(
                "FAIL-CLOSED: Ungültige Tool-Aktion."
            )

        return obj

    if set(obj) == {
        "action",
        "arguments",
    }:
        if obj["action"] not in TOOL_NAMES:
            raise RuntimeError(
                "FAIL-CLOSED: Unbekannte Kurzformat-Aktion."
            )

        return {
            "action": "tool",
            "name": obj["action"],
            "arguments": obj["arguments"],
        }

    if set(obj) == {
        "action",
        "result",
    }:
        if obj["action"] != "done":
            raise RuntimeError(
                "FAIL-CLOSED: Ungültige Abschlussaktion."
            )

        if not isinstance(
            obj["result"],
            str,
        ):
            raise RuntimeError(
                "FAIL-CLOSED: result ungültig."
            )

        return obj

    raise RuntimeError(
        "FAIL-CLOSED: Unbekanntes Antwortschema."
    )


# =========================================================
# AGENT LOOP
# =========================================================

def run_agent(task):
    state = load_state()
    policy = build_mission_policy()
    budget = MissionBudget()

    verify_audit_chain()

    audit(
        "MISSION_START",
        {
            "task": task,
            "model": MODEL,
            "policy": policy,
            "policy_digest": policy_digest(
                policy
            ),
            "budgets": {
                "total": MAX_TOOL_CALLS,
                "reads": MAX_READ_CALLS,
                "writes": MAX_WRITE_CALLS,
                "execs": MAX_EXEC_CALLS,
            },
        },
    )

    system_prompt = """
Du bist ein sicherer autonomer Entwickler-Agent.

Du arbeitest ausschließlich in /workspace.

Verfügbare Werkzeuge:

{"action":"tool","name":"list_files","arguments":{}}

{"action":"tool","name":"read_file","arguments":{"path":"datei.txt"}}

{"action":"tool","name":"write_file","arguments":{"path":"datei.txt","content":"TEXT"}}

{"action":"tool","name":"run_python","arguments":{"script":"test.py","args":[]}}

Abschluss:

{"action":"done","result":"..."}

Ein einzelner ```json-Codeblock ist erlaubt.

Regeln:
- Kein Shell.
- Kein bash.
- Kein sh.
- Kein exec.
- Kein subprocess.
- Kein Text vor dem JSON.
- Kein Text nach dem JSON.
- Genau ein JSON-Objekt pro Antwort.
- Nur /workspace verändern.
- Niemals /agent verändern.
- Prüfe jedes Tool-Ergebnis.
"""

    messages = [
        {
            "role": "system",
            "content": system_prompt,
        },
        {
            "role": "user",
            "content": (
                "AUFGABE:\n"
                + task
                + "\n"
                "Beginne jetzt."
            ),
        },
    ]

    for step in range(
        1,
        MAX_STEPS + 1,
    ):
        print()
        print(
            f"=== STEP {step}/{MAX_STEPS} ==="
        )

        response = ask_model(
            messages
        )

        print("MODEL:")
        print(response)

        action = parse_action(
            response
        )

        messages.append(
            {
                "role": "assistant",
                "content": response,
            }
        )

        if action["action"] == "done":
            result = action["result"]

            state["tasks_completed"] += 1
            state["last_result"] = result

            save_state(state)

            audit(
                "MISSION_DONE",
                {
                    "step": step,
                    "result": result,
                    "tool_usage": {
                        "total": budget.total,
                        "reads": budget.reads,
                        "writes": budget.writes,
                        "execs": budget.execs,
                    },
                },
            )

            print()
            print("=== DONE ===")
            print(result)
            return

        try:
            result = execute_tool(
                action["name"],
                action["arguments"],
                policy,
                budget,
            )

        except Exception as exc:
            result = {
                "status": "ERROR",
                "error": type(exc).__name__,
                "message": str(exc),
            }

        audit(
            "TOOL",
            {
                "step": step,
                "name": action["name"],
                "status": (
                    result.get(
                        "status",
                        "OK",
                    )
                    if isinstance(
                        result,
                        dict,
                    )
                    else "OK"
                ),
                "usage": {
                    "total": budget.total,
                    "reads": budget.reads,
                    "writes": budget.writes,
                    "execs": budget.execs,
                },
            },
        )

        print("RESULT:")
        print(
            json.dumps(
                result,
                ensure_ascii=False,
                indent=2,
            )
            if isinstance(
                result,
                (dict, list),
            )
            else result
        )

        messages.append(
            {
                "role": "user",
                "content": (
                    "TOOL-ERGEBNIS:\n"
                    + json.dumps(
                        result,
                        ensure_ascii=False,
                    )
                    + "\n"
                    "Analysiere das Ergebnis und fahre fort."
                ),
            }
        )

    state["last_result"] = (
        "FAIL-CLOSED: Schrittlimit erreicht."
    )

    save_state(state)

    audit(
        "MISSION_ABORTED",
        {
            "reason": "step_limit",
            "max_steps": MAX_STEPS,
            "tool_usage": {
                "total": budget.total,
                "reads": budget.reads,
                "writes": budget.writes,
                "execs": budget.execs,
            },
        },
    )

    raise RuntimeError(
        "FAIL-CLOSED: Maximale Schrittzahl erreicht."
    )


def main():
    if len(sys.argv) < 2:
        print(
            'Usage: python3 safe_agent_v44.py "AUFGABE"'
        )
        raise SystemExit(2)

    print("=== SAFE AGENT V44 ===")
    print("Project:", ROOT)
    print("Runtime:", RUNTIME)
    print("Model:", MODEL)
    print(
        "Policy:",
        os.environ.get(
            "SAFE_AGENT_POLICY",
            "default",
        ),
    )

    run_agent(
        " ".join(sys.argv[1:])
    )


if __name__ == "__main__":
    main()
PY


cat > tests/test_v44.py <<'PY'
import json

import safe_agent_v44 as agent


RUNTIME = agent.RUNTIME


def expect_blocked(label, fn):
    print("[TEST]", label)

    try:
        fn()
    except Exception as exc:
        print(
            "       BLOCKED:",
            type(exc).__name__,
        )
        return

    raise AssertionError(
        f"{label}: nicht blockiert"
    )


def test_policy():
    policy = agent.build_mission_policy()

    assert set(policy) == {
        "list_files",
        "read_file",
        "write_file",
        "run_python",
    }


def test_readonly_policy():
    import os

    old = os.environ.get(
        "SAFE_AGENT_POLICY"
    )

    os.environ["SAFE_AGENT_POLICY"] = "readonly"

    try:
        policy = agent.build_mission_policy()

        assert policy["read_file"] is True
        assert policy["write_file"] is False
        assert policy["run_python"] is False

    finally:
        if old is None:
            os.environ.pop(
                "SAFE_AGENT_POLICY",
                None,
            )
        else:
            os.environ["SAFE_AGENT_POLICY"] = old


def test_tool_allowlist():
    budget = agent.MissionBudget()
    policy = agent.DEFAULT_POLICY

    expect_blocked(
        "Unknown tool",
        lambda: agent.execute_tool(
            "shell",
            {},
            policy,
            budget,
        ),
    )


def test_path_policy():
    for path in [
        "../escape.txt",
        "../../escape.txt",
        "/etc/shadow",
        "/var/home/mklein/x",
    ]:
        expect_blocked(
            f"Path {path}",
            lambda p=path: agent.write_file(
                p,
                "X",
            ),
        )


def test_workspace_prefix():
    target = "v44_prefix.txt"

    agent.write_file(
        "/workspace/" + target,
        "PREFIX_OK",
    )

    assert agent.read_file(
        target
    ) == "PREFIX_OK"

    (
        RUNTIME / target
    ).unlink()


def test_budget():
    budget = agent.MissionBudget()

    budget.consume(
        "write_file"
    )

    assert budget.total == 1
    assert budget.writes == 1


def test_policy_blocks_write():
    budget = agent.MissionBudget()

    expect_blocked(
        "Readonly write",
        lambda: agent.execute_tool(
            "write_file",
            {
                "path": "x.txt",
                "content": "X",
            },
            agent.READ_ONLY_POLICY,
            budget,
        ),
    )


def test_policy_blocks_exec():
    budget = agent.MissionBudget()

    expect_blocked(
        "Noexec run_python",
        lambda: agent.execute_tool(
            "run_python",
            {
                "script": "x.py",
            },
            agent.NO_EXEC_POLICY,
            budget,
        ),
    )


def test_limits():
    budget = agent.MissionBudget()

    budget.total = agent.MAX_TOOL_CALLS

    expect_blocked(
        "Total budget",
        lambda: budget.check(
            "read_file"
        ),
    )


def test_parser_formats():
    direct = json.dumps({
        "action": "done",
        "result": "OK",
    })

    assert (
        agent.parse_action(direct)["action"]
        == "done"
    )

    fenced = (
        "```json\n"
        '{"action":"done","result":"FENCED"}'
        "\n```"
    )

    assert (
        agent.parse_action(
            fenced
        )["result"]
        == "FENCED"
    )

    shorthand = json.dumps({
        "action": "write_file",
        "arguments": {
            "path": "a.txt",
            "content": "A",
        },
    })

    parsed = agent.parse_action(
        shorthand
    )

    assert parsed["name"] == "write_file"


def test_parser_rejects_prose():
    expect_blocked(
        "Prose",
        lambda: agent.parse_action(
            "Hier:\n"
            '{"action":"done","result":"BAD"}'
        ),
    )


def test_audit_chain():
    agent.audit(
        "V44_TEST",
        {"ok": True},
    )

    assert (
        agent.verify_audit_chain()
    )


if __name__ == "__main__":
    tests = [
        test_policy,
        test_readonly_policy,
        test_tool_allowlist,
        test_path_policy,
        test_workspace_prefix,
        test_budget,
        test_policy_blocks_write,
        test_policy_blocks_exec,
        test_limits,
        test_parser_formats,
        test_parser_rejects_prose,
        test_audit_chain,
    ]

    for test in tests:
        test()

    print()
    print("V44 TESTS OK")
PY


cat > tools/test_all_v44.sh <<'BASH2'
#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"

python3 -m py_compile safe_agent_v44.py

python3 tests/test_v44.py

python3 - <<'PY'
import safe_agent_v44 as agent

state = agent.load_state()

agent.verify_state_hash(
    state
)

agent.verify_audit_chain()

print("STATE OK")
print("AUDIT CHAIN OK")
PY

echo
echo "V44 TESTS PASSED"
BASH2

chmod +x tools/test_all_v44.sh


cat > tools/test_end_to_end_v44.sh <<'BASH3'
#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
export OLLAMA_MODEL="${OLLAMA_MODEL:-qwen2.5-coder:7b-instruct}"
export OLLAMA_URL="${OLLAMA_URL:-http://127.0.0.1:11434/api/chat}"

echo "=========================================="
echo " V44 END-TO-END"
echo "=========================================="

./tools/test_all_v44.sh

echo
echo "=== OLLAMA ==="

python3 - <<'PY'
import json
import os
import urllib.request

payload = {
    "model": os.environ["OLLAMA_MODEL"],
    "messages": [
        {
            "role": "user",
            "content": (
                'Antworte exakt mit '
                '{"action":"done","result":"OLLAMA_V44_OK"}'
            ),
        }
    ],
    "stream": False,
}

req = urllib.request.Request(
    os.environ["OLLAMA_URL"],
    data=json.dumps(payload).encode(),
    headers={
        "Content-Type": "application/json",
    },
)

with urllib.request.urlopen(
    req,
    timeout=60,
) as response:
    body = json.load(response)

content = body["message"]["content"]

print(content)

if "OLLAMA_V44_OK" not in content:
    raise SystemExit(
        "OLLAMA FAIL"
    )
PY

echo "OLLAMA V44 OK"

echo
echo "=== REAL AGENT ==="

rm -f runtime/v44_agent_test.txt

python3 safe_agent_v44.py \
    "Erstelle v44_agent_test.txt mit exakt V44_AGENT_OK. Lies die Datei danach wieder ein. Prüfe den Inhalt und antworte erst dann mit done."

test -f runtime/v44_agent_test.txt

test "$(
    cat runtime/v44_agent_test.txt
)" = "V44_AGENT_OK"

echo "REAL AGENT OK"

echo
echo "=== POLICY MODE ==="

SAFE_AGENT_POLICY=noexec \
python3 - <<'PY'
import safe_agent_v44 as agent

policy = agent.build_mission_policy()

assert policy["run_python"] is False
assert policy["write_file"] is True

print("NOEXEC POLICY OK")
PY

echo
echo "=== FINAL ==="

test -f safe_agent_v44.py

echo "V44 END-TO-END TESTS PASSED"
BASH3

chmod +x tools/test_end_to_end_v44.sh


cat > BUILD_INFO_V44.txt <<EOF
SAFE AGENT V44

Built: $(date -Is)
Model: ${OLLAMA_MODEL}
Ollama URL: ${OLLAMA_URL}

Mission policy:
- default
- readonly
- noexec

Tool budgets:
- total
- reads
- writes
- execution

Security:
- direct tools
- strict path validation
- workspace prefix normalization
- content limit
- argument limit
- isolated Python execution
- network namespace disabled
- capabilities dropped
- agent code read-only
- audit hash chain
EOF


python3 -m py_compile safe_agent_v44.py

echo
echo "=== V44 BUILD ==="
./tools/test_all_v44.sh

echo
echo "=== V44 END-TO-END ==="
./tools/test_end_to_end_v44.sh

echo
echo "=========================================="
echo " SAFE AGENT V44 READY"
echo "=========================================="
